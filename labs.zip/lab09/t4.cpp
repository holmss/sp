/*  MPA2019   */
#include "mlisp.h"
double f(double x, double y);//DECLARATION
//________________ 
double f(double x, double y){//DEFINITION
  return x * y;
}
int main(){
 display("No calculations!");newline();
 std::cin.get();
 return 0;
}

