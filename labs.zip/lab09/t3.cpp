/*  MPA2019   */
#include "mlisp.h"
//________________ 
int main(){
 display(e); newline();
 display(pi); newline();
 std::cin.get();
 return 0;
}

