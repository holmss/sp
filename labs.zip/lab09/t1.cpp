/*  MPA2019   */
#include "mlisp.h"
//________________ 
int main(){
 display(pi); newline();
 std::cin.get();
 return 0;
}

