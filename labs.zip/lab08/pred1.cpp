/*  MPA2019   */
#include "mlisp.h"
bool ne_Q(double x, double y);
//________________ 
bool ne_Q(double x, double y){
  return (0 == (((x == y)) ? e : 0));
}

