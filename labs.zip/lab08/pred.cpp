/*  MPA2019   */
#include "mlisp.h"
bool _Q(double x, double y);
//________________ 
bool _Q(double x, double y){
  return true;
}

