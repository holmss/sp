//               testadec.cpp
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include "fsm.h"
using namespace std;

int main()
{
	tFSM Adec;
	tFSM fsm;
	///////////////////////
	//  �������� �������
	addrange(Adec, 0, '1', '9', 1);
	addrange(Adec, 1, '0', '9', 1);
	addstr  (Adec, 1, ".", 2);
	addrange(Adec, 2, '0', '9', 2);
	//......................
	Adec.final(2);
	//......................
	///////////////////////
	cout << "LVD Adec "
		<< "size=" << Adec.size()
		<< " LVD\n";
	cout << endl;
	
	//������� �2
	///////////////////////
//  �������� �������
  addstr(fsm,0,"_",1);
  addrange(fsm,0,'A','Z',1);
  addrange(fsm,0,'a','z',1);
  addstr(fsm,1,"_",1);
  addrange(fsm,1,'A','Z',1);
  addrange(fsm,1,'a','z',1);
  addrange(fsm,1,'0','9',1);
  fsm.final(1);
///////////////////////

  cout << "*** cppid  "
       << "size=" << fsm.size()
       << " ***\n";
  cout << endl;

	while(true)
	{
		char input[81];
		cout << ">";
		cin.getline(input, 81);
		if(!*input) break;
		int res = Adec.apply(input);
		//cout << setw(res? res + 1 : 0) << "^"
		//	<< endl;
		if(res)
		cout << setw(res+1) <<"^" << endl;
		if(!res)
		{	
		int res2 = fsm.apply(input);
  		cout << setw(res2?res2+1:0) << "^"
       		<< endl;
		}
	}
	return 0;
}
