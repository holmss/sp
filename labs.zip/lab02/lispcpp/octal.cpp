//octal.cpp
/*
 015
+015
-015
-015.0
-015e+0
*/
#include "mlisp.h"
int main(){
 display(015);newline();
 display(+015);newline();
 display(-015);newline();
 display(-015.0);newline();
 display(-015e+0);newline();
std::cin.get();
 return 0;
}
